# My-Portfolio

<!-- Link to preview the portfolio in a new tab -->
<h2>
<a href="https://htmlpreview.github.io/?https://raw.githubusercontent.com/potdukhe12/My-Portfolio/main/Saurabh%20Potdukhe.html" 
      target="_blank" rel="noopener"  style="font-size: 2em">
  Web Preview
</a>
</h2>
<h4>Sample:</h4>
<img src="./Portfolio.png" />
